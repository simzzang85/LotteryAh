<!DOCTYPE html>
<html>
	<body>
		<?php include('include/top.php'); ?>
		<h1>My first PHP page</h1>
		<?php include('include/bottom.php'); ?>
	</body>
</html>