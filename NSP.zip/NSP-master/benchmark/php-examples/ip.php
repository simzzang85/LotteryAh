<!DOCTYPE html>
<html>
	<body>
		<h1>IP Example</h1>
		<p><?=$_SERVER['REMOTE_ADDR'] ?></p>
		<a href="/">Home</a>
	</body>
</html>