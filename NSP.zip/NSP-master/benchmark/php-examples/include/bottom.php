<p><?=$msg ?></p>
<a href="/">Home</a>