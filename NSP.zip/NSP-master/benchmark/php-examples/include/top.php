<?php
	$local = 'Welcome!';
	
	$msg = 'Hello World! '.$local;
?>