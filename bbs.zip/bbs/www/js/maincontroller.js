
var MainController = angular.module('MainController', []);

MainController.controller("HomeCtrl",['$scope','$http', function ($scope, $http){
	$http.get('api/articles').success(function(dataSet) {
		console.log("============HomeCtrl=======");
		console.log(dataSet.toString());
		$scope.dataSet = dataSet;
		console.log("===========================");
	});
	$scope.postIt = function() {
		alert("posting...");
		// XMLHttpRequest cannot load http://127.0.0.1:1337/. No 'Access-Control-Allow-Origin' header is present on the requested resource. Origin 'null' is therefore not allowed access. 
//		$http.get('api/articles.nsp', {msg:'hello from Angular.js!'})
//		.success(function onSuccess(response){
//	        console.log("response::::::"+response);
//	        $scope.testData = response;
//	    }).error(function onError(){
//	        console.log("AJAX failed!");
//	    });
    };
}]);	
MainController.controller('WriteCtrl', ['$scope', '$http', '$location',
	function($scope, $http, $location) {
		console.log("============WriteCtrl=======");
		$scope.submit = function(title, contents) {
			console.log("===========================");
		};
}]);

MainController.controller('ViewCtrl', ['$scope', '$http', '$routeParams',
	function($scope, $http, $routeParams) {//when include parameters, use $routeParams.
		console.log("============ViewCtrl=======");
		$http.get('api/articles/'+ $routeParams.id).success(function(data){
			$scope.data = data;
			console.log("===========================");
		});
}]);

MainController.controller('UpdateCtrl',['$scope','$http','$location','$routeParams', 
	function($scope, $http, $location, $routeParams){
		console.log("============UpdateCtrl=======");
		//"get" with id 
		$http.get('api/articles/'+$routeParams.id)
		.then(
			function(data){
				//success code
				$scope.title = data.data[0].title;
				$scope.contents = data.data[0].contents;
			}
			,function(err){
				console.log("::UPDATE ERR::"+ err);
			}
		);
		
		$scope.submit = function(title, contents){
			if($routeParams.id !== undefined && title !== undefined && contents !== undefined){
				console.log("FRONT PUT::::"+ title+"::::"+contents);
				$http.put('api/articles/'+$routeParams.id,  'title=' + encodeURIComponent(title) + '&contents=' + encodeURIComponent(contents))
	            .then(
	            	       function(data, status){
//	            	          success callback
	       					$location.path('view/'+$routeParams.id);
	            	       }, 
	            	       function(err){
//	            	          failure callback
	       					console.log(":::UPDATECTRL333-1:::"+ err);
	            	       }
	            	    );

			}
			else {
			}
		};
}]);




