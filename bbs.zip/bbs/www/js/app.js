
var app = angular.module('MyAngularApp',['ngRoute', 'MainController']);
app.config(['$routeProvider',
function($routeProvider){
	$routeProvider.when('/',{
		templateUrl : 'home.html'
		,controller : 'HomeCtrl'
	}).when('/write', {
		templateUrl : 'write.html'
		,controller : 'WriteCtrl'
	}).when('/view/:id',{
		templateUrl : 'view.html'
		,controller : 'ViewCtrl'
	}).when('/update/:id',{
		templateUrl : 'update.html'
		,controller : 'UpdateCtrl'
	}).when('/remove/:id',{
		templateUrl : 'remove.html'
		,controller : 'RemoveCtrl'
		}).otherwise({
		redirectTo : '/'
	});
}]);

