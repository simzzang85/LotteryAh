# nsp-sample-bbs-mysql
[NSP](https://github.com/Hanul/NSP)로 제작한 게시판 샘플 프로젝트 입니다.
- MySQL 사용
- [node-mysql](https://github.com/felixge/node-mysql) 모듈 사용