module.exports = require('mysql').createPool({
	host : 'localhost',
	user : 'nsp-sample-bbs',
	password : 'test',
	database : 'nsp-sample-bbs'
});
