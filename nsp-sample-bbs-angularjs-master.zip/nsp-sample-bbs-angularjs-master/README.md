# nsp-sample-bbs-angularjs
[NSP](https://github.com/Hanul/NSP)로 제작한 게시판 샘플 프로젝트 입니다.
- AngularJS 사용