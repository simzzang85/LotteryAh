# express-tutorial
 VELOPERT 블로그에 작성한 ExpressJS 강좌에 사용된 프로젝트 입니다.
 Node.js 와 Express.js 의 기초를 다지는데 목적을 두었으므로 소스코드의 보안 및 실용성은 다소 낮습니다.

프로젝트에서 다루는 개념은 Express 프로젝트 환경 설정 및 EJS, RESTful API, express-session 입니다.

 - [\[Node.JS\] 강좌 09편: Express 프레임워크 사용해보기](https://velopert.com/294)
 - [\[Node.JS\] 강좌 10-1편: Express 프레임워크 응용하기 – EJS](https://velopert.com/294)
 - [\[Node.JS\] 강좌 10-2편: Express 프레임워크 응용하기 – RESTful API 편](https://velopert.com/332)
 - [\[Node.JS\] 강좌 10-3편: Express 프레임워크 응용하기 – express-session 편](https://velopert.com/406)

