# nsp-sample-restful
[NSP](https://github.com/Hanul/NSP)로 제작한 RESTful API 샘플 프로젝트입니다.
- MongoDB 사용
- [node-mongodb-native](https://github.com/mongodb/node-mongodb-native) 모듈 사용